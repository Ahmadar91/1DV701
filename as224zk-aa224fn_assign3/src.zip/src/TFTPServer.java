import Client.Client;
import Packet.PacketFactory;

import java.io.IOException;
import java.net.*;

/**
 * The type Tftp server.
 */
public class TFTPServer
{
    private static final int TFTPPORT = 4970;
    private static final int BUFSIZE = 516;
    private int index = 1;
    // Please change the path
    private static final String inPath = "S:\\Computer Networks\\Assignment 3\\src\\Files\\in/";
    private static final String outPath = "S:\\Computer Networks\\Assignment 3\\src\\Files\\out/";

    /**
     * The entry point of application.
     *
     * @param args the input arguments
     */
    public static void main(String[] args)
    {

        if (args.length > 0)
        {
            System.err.printf("usage: java %s\n", TFTPServer.class.getCanonicalName());
            System.exit(1);
        }
        //Starting the server
        try
        {
            TFTPServer server = new TFTPServer();
            server.start();
        } catch (SocketException e)
        {
            e.printStackTrace();
        }
    }

    private void start() throws SocketException
    {
        byte[] buf = new byte[BUFSIZE];

        // Create socket
        DatagramSocket socket = new DatagramSocket(null);

        // Create local bind point
        SocketAddress localBindPoint = new InetSocketAddress(TFTPPORT);
        socket.bind(localBindPoint);

        System.out.printf("Listening at port %d for new requests\n", TFTPPORT);

        // Loop to handle client requests
        while (true)
        {
            DatagramPacket datagramPacket = new DatagramPacket(buf, buf.length);
            try
            {
                socket.receive(datagramPacket);
            } catch (IOException e)
            {
                System.err.println(e.getMessage());
                continue;
            }
            InetSocketAddress inetSocketAddress = (InetSocketAddress) datagramPacket.getSocketAddress();
            Client client = new Client(index++, inPath, outPath, inetSocketAddress);

            if (!client.setBuffer(buf, datagramPacket.getLength()))
            {
                continue;
            }
            client.start();
        }
    }
}



