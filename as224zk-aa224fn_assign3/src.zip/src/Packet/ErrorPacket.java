package Packet;

/**
 * The type Error packet.
 */
public class ErrorPacket extends Packet {
    private ErrorCode errorCode;
    private String errorMessage;

    /**
     * Instantiates a new Error packet.
     */
    public ErrorPacket() {
        super(OpCode.ERROR);
    }

    /**
     * Instantiates a new Error packet.
     *
     * @param errorCode    the error code
     * @param errorMessage the error message
     */
    public ErrorPacket(ErrorCode errorCode, String errorMessage) {
        super(OpCode.ERROR);
        setErrorCode(errorCode);
        setErrorMessage(errorMessage);
    }

    /**
     * Sets error code.
     *
     * @param errorCode the error code
     */
    public void setErrorCode(ErrorCode errorCode) {
        this.errorCode = errorCode;
    }

    /**
     * Sets error message.
     *
     * @param errorMessage the error message
     */
    public void setErrorMessage(String errorMessage) {
        this.errorMessage = errorMessage;
    }
}
