
package Packet;
import java.nio.ByteBuffer;

/**
 * The type Packet factory.
 */
public class PacketFactory
{
    /**
     * From buffer packet.
     *
     * @param buf    the buf
     * @param length the length
     * @return the packet
     */
    public static Packet fromBuffer(byte[] buf, int length)
    {
        if ((buf == null) || (buf.length < 516))
        {
            return null;
        }

        if (length < 2) {
            return null;
        }
        ByteBuffer wrap0 = ByteBuffer.wrap(buf, 0, 2);

        OpCode opCode = OpCode.toOpCode(wrap0.getShort());
        switch (opCode)
        {
            case RRQ:
            case WRQ:
            {
                if (length < 4) {
                    return null;
                }
                String fileName = extractString(buf, 2);
                if (fileName.isEmpty())
                {
                    return null;
                }
                String mode = extractString(buf, 2 + fileName.length() + 1);
                if (mode.isEmpty())
                {
                    return null;
                }
                return new RequestPacket(opCode, fileName, mode);
            }
            case DATA:
            {
                if (length < 4) {
                    return null;
                }
                ByteBuffer wrap1 = ByteBuffer.wrap(buf, 2, 2);


                byte[] data = new byte[length];
                System.arraycopy(buf, 4, data, 0, length - 4);
                return new DataPacket(wrap1.getShort(), data, length - 4);
            }
            case ACK:
            {
                if (length < 4) {
                    return null;
                }

                ByteBuffer wrap = ByteBuffer.wrap(buf, 2, 2);
                short blockNumber = wrap.getShort();
                return new AcknowledgePacket(blockNumber);
            }

            case ERROR:
            {
                if (length < 5) {
                    return null;
                }
                ByteBuffer wrap = ByteBuffer.wrap(buf, 2, 2);
                ErrorCode errorCode = ErrorCode.fromShort(wrap.getShort());
                if (errorCode == ErrorCode.NONE)
                {
                    return null;
                }
                String errorMessage = extractString(buf, 4);
                if (errorMessage.isEmpty())
                {
                    return null;
                }
                return new ErrorPacket(errorCode, errorMessage);
            }
            default:
            {
                return null;
            }
        }
    }

    /**
     * Create data packet data packet.
     *
     * @param blockNumber the block number
     * @param inBuffer    the in buffer
     * @param inLen       the in len
     * @return the data packet
     */
    public static DataPacket createDataPacket(short blockNumber, byte[] inBuffer, short inLen)
    {
        DataPacket out = new DataPacket();
        byte[] buffer;
        try
        {
            buffer = new byte[inLen + 4]; // 4 four op code and block
        } catch (Exception exception)
        {
            return null;
        }


        buffer[0] = (byte) (out.getOpCode().getValue() >> 0x08);
        buffer[1] = (byte) (out.getOpCode().getValue() & 0xff);
        buffer[2] = (byte) (blockNumber >> 0x08);
        buffer[3] = (byte) (blockNumber & 0xff);

        // Copy data
        if (inLen > 0)
        {
            System.arraycopy(inBuffer, 0, buffer, 4, inLen);
        }
        out.setBuffer(buffer);
        return out;
    }

    /**
     * Create acknowledge packet acknowledge packet.
     *
     * @param blockNumber the block number
     * @return the acknowledge packet
     */
    public static AcknowledgePacket createAcknowledgePacket(short blockNumber)
    {
        AcknowledgePacket out = new AcknowledgePacket();

        byte[] buffer;
        try
        {
            buffer = new byte[4]; // 4 four op code and block
        } catch (Exception exception)
        {
            return null;
        }


        //
        buffer[0] = (byte) (out.getOpCode().getValue() >> 0x08);
        buffer[1] = (byte) (out.getOpCode().getValue() & 0xff);
        buffer[2] = (byte) (blockNumber >> 0x08);
        buffer[3] = (byte) (blockNumber & 0xff);

        out.setBuffer(buffer);
        return out;
    }

    /**
     * Create error packet error packet.
     *
     * @param errorCode the error code
     * @return the error packet
     */
    public static ErrorPacket createErrorPacket(ErrorCode errorCode)
    {
        return createErrorPacket(errorCode, ErrorCode.toString(errorCode));
    }

    /**
     * Create error packet error packet.
     *
     * @param errorCode    the error code
     * @param errorMessage the error message
     * @return the error packet
     */
    public static ErrorPacket createErrorPacket(ErrorCode errorCode, String errorMessage)
    {
        ErrorPacket out = new ErrorPacket();

        byte[] buffer;
        try
        {
            buffer = new byte[2 + 2 + errorMessage.length() + 1]; // 4 four op code and block
        } catch (Exception exception)
        {
            return null;
        }

        //
        buffer[0] = (byte) (out.getOpCode().getValue() >> 0x08);
        buffer[1] = (byte) (out.getOpCode().getValue() & 0xff);
        buffer[2] = (byte) (errorCode.value >> 0x08);
        buffer[3] = (byte) (errorCode.value & 0xff);
        System.arraycopy(errorMessage.getBytes(), 0, buffer, 4, errorMessage.getBytes().length);

        out.setBuffer(buffer);
        return out;
    }

    private static String extractString(byte[] buf, int offset)
    {
        int stringLen = 0;
        while ((offset + stringLen) < buf.length)
        {
            if (buf[offset + stringLen] == 0x00)
            {
                break;
            }
            ++stringLen;
        }
        return new String(buf, offset, stringLen);
    }

}
