package Packet;

/**
 * The enum Op code.
 */
public enum OpCode {/**
 * None op code.
 */
NONE((short) 0),
    /**
     * Rrq op code.
     */
    RRQ((short) 1),
    /**
     * Wrq op code.
     */
    WRQ((short) 2),
    /**
     * Data op code.
     */
    DATA((short) 3),
    /**
     * Ack op code.
     */
    ACK((short) 4),
    /**
     * Error op code.
     */
    ERROR((short) 5);

    private short value;

    OpCode(short value) {
        this.value = value;
    }

    /**
     * Gets value.
     *
     * @return the value
     */
    public short getValue() {
        return value;
    }

    /**
     * To string string.
     *
     * @param opCode the op code
     * @return the string
     */
    public static String toString(OpCode opCode) {
        switch (opCode) {
            case RRQ:
                return "RRQ";
            case WRQ:
                return "WRQ";
            case DATA:
                return "DATA";
            case ACK:
                return "ACk";
            case ERROR:
                return "ERROR";
            default:
                return "NONE";
        }
    }

    /**
     * To op code op code.
     *
     * @param value the value
     * @return the op code
     */
    public static OpCode toOpCode(short value) {
        switch (value) {
            case 1:
                return RRQ;
            case 2:
                return WRQ;
            case 3:
                return DATA;
            case 4:
                return ACK;
            case 5:
                return RRQ;
            default:
                return NONE;
        }
    }
}
