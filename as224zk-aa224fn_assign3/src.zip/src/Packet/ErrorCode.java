package Packet;

/**
 * The enum Error code.
 */
public enum ErrorCode {/**
 * Not defined error code.
 */
NOT_DEFINED((short) 0),
    /**
     * File not found error code.
     */
    FILE_NOT_FOUND((short) 1),
    /**
     * Access violation error code.
     */
    ACCESS_VIOLATION((short) 2),
    /**
     * Disk full or allocation exceeded error code.
     */
    DISK_FULL_OR_ALLOCATION_EXCEEDED((short) 3),
    /**
     * Illegal tftp operation error code.
     */
    ILLEGAL_TFTP_OPERATION((short) 4),
    /**
     * Unknown transfer id error code.
     */
    UNKNOWN_TRANSFER_ID((short) 5),
    /**
     * File already exists error code.
     */
    FILE_ALREADY_EXISTS((short) 6),
    /**
     * No such user error code.
     */
    NO_SUCH_USER((short) 7),
    /**
     * None error code.
     */
    NONE((short) 8);


    /**
     * The Value.
     */
    short value;

    ErrorCode(short value) {
        this.value = value;
    }

    /**
     * To string string.
     *
     * @param errorCode the error code
     * @return the string
     */
    public static String toString(ErrorCode errorCode) {
        switch (errorCode) {
            case NOT_DEFINED:
                return "Not defined.";
            case FILE_NOT_FOUND:
                return "File not found.";
            case ACCESS_VIOLATION:
                return "Access violation.";
            case DISK_FULL_OR_ALLOCATION_EXCEEDED:
                return "Disk full or allocation exceeded.";
            case ILLEGAL_TFTP_OPERATION:
                return "Illegal TFTP operation.";
            case UNKNOWN_TRANSFER_ID:
                return "Unknown transfer ID.";
            case FILE_ALREADY_EXISTS:
                return "File already exists.";
            case NO_SUCH_USER:
                return "No such user.";
            default:
                return "";
        }
    }

    /**
     * From short error code.
     *
     * @param value the value
     * @return the error code
     */
    public static ErrorCode fromShort(short value) {
        switch (value) {
            case 0:
                return NOT_DEFINED;
            case 1:
                return FILE_NOT_FOUND;
            case 2:
                return ACCESS_VIOLATION;
            case 3:
                return DISK_FULL_OR_ALLOCATION_EXCEEDED;
            case 4:
                return ILLEGAL_TFTP_OPERATION;
            case 5:
                return UNKNOWN_TRANSFER_ID;
            case 6:
                return FILE_ALREADY_EXISTS;
            case 7:
                return NO_SUCH_USER;
            default:
                return NONE;
        }
    }

}
