package Packet;

/**
 * The type Acknowledge packet.
 */
public class AcknowledgePacket extends Packet {
    private short blockNumber;

    /**
     * Instantiates a new Acknowledge packet.
     */
    public AcknowledgePacket() {
        super(OpCode.ACK);
    }

    /**
     * Instantiates a new Acknowledge packet.
     *
     * @param blockNumber the block number
     */
    public AcknowledgePacket(short blockNumber) {
        super(OpCode.ACK);
        setBlockNumber(blockNumber);
    }

    /**
     * Gets block number.
     *
     * @return the block number
     */
    public short getBlockNumber() {
        return blockNumber;
    }

    /**
     * Sets block number.
     *
     * @param blockNumber the block number
     */
    public void setBlockNumber(short blockNumber) {
        this.blockNumber = blockNumber;
    }
}
