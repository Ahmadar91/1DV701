package Packet;

/**
 * The type Data packet.
 */
public class DataPacket extends Packet {
    private short blockNumber;
    private byte[] data;

    /**
     * Instantiates a new Data packet.
     */
    public DataPacket() {
        super(OpCode.DATA);
    }

    /**
     * Instantiates a new Data packet.
     *
     * @param blockNumber the block number
     * @param data        the data
     * @param length      the length
     */
    public DataPacket(short blockNumber, byte[] data, int length) {
        super(OpCode.DATA);
        setBlockNumber(blockNumber);
        setData(data, length);
    }


    /**
     * Sets block number.
     *
     * @param blockNumber the block number
     */
    public void setBlockNumber(short blockNumber) {
        this.blockNumber = blockNumber;
    }

    public byte[] getData() {
        return data;
    }

    public void setData(byte[] data, int length) {
        this.data = new byte[length];
        System.arraycopy(data, 0, this.data, 0, length);
    }
}
