package Packet;

/**
 * The type Request packet.
 */
public class RequestPacket extends Packet {
    private String fileName;
    private String mode;

    /**
     * Instantiates a new Request packet.
     *
     * @param opCode   the op code
     * @param fileName the file name
     * @param mode     the mode
     */
    RequestPacket(OpCode opCode, String fileName, String mode) {
        super(opCode);
        setFileName(fileName);
        setMode(mode);
    }

    /**
     * Gets file name.
     *
     * @return the file name
     */
    public String getFileName() {
        return fileName;
    }

    /**
     * Sets file name.
     *
     * @param fileName the file name
     */
    public void setFileName(String fileName) {
        this.fileName = fileName;
    }


    /**
     * Sets mode.
     *
     * @param mode the mode
     */
    public void setMode(String mode) {
        this.mode = mode;
    }
}
