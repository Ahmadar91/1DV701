package Packet;

/**
 * The type Packet.
 */
public class Packet {
    private OpCode opCode;
    private byte[] buffer;

    /**
     * Instantiates a new Packet.
     *
     * @param opCode the op code
     */
    Packet(OpCode opCode) {
        this.opCode = opCode;
    }

    /**
     * Gets op code.
     *
     * @return the op code
     */
    public OpCode getOpCode() {
        return opCode;
    }

    /**
     * Sets op code.
     *
     * @param opCode the op code
     */
    public void setOpCode(OpCode opCode) {
        this.opCode = opCode;
    }

    /**
     * Get buffer byte [ ].
     *
     * @return the byte [ ]
     */
    public byte[] getBuffer() {
        return buffer;
    }

    public void setBuffer(byte[] buffer) {
        this.buffer = buffer;
    }
}
