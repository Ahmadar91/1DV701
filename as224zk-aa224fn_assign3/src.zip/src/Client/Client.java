package Client;

import Packet.*;

import java.io.*;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetSocketAddress;
import java.net.SocketException;
import java.nio.ByteBuffer;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Client extends Thread
{
    private int id;
    private byte[] buffer;
    private int len;
    private InetSocketAddress inetSocketAddress;
    private DatagramSocket socket;
    private String inPath;
    private String outPath;
    private boolean active = true; // This boolean is created to to kill the client connection, used to show not defined error

    public Client(int id, String inPath, String outPath, InetSocketAddress inetSocketAddress)
    {
        this.inetSocketAddress = inetSocketAddress;
        setId(id);
        setInPath(inPath);
        setOutPath(outPath);
    }

    public void setInPath(String inPath)
    {
        this.inPath = inPath;
    }

    public void setOutPath(String outPath)
    {
        this.outPath = outPath;
    }

    public long getId()
    {
        return id;
    }

    public void setId(int id)
    {
        this.id = id;
    }

    public boolean setBuffer(byte[] buffer, int len)
    {
        try
        {
            this.buffer = new byte[516];
            this.len = len;
        } catch (Exception exception)
        {
            logMessage("failed to initialize buffer");
            return false;
        }
        System.arraycopy(buffer, 0, this.buffer, 0, len);
        return true;
    }

    public void logMessage(String message)
    {
        SimpleDateFormat sdf = new SimpleDateFormat("HH:mm:ss");
        System.out.printf(sdf.format(new Date(System.currentTimeMillis())) + " [%d]: %s\n", id, message);
    }

    @Override
    public void run()
    {
        logMessage("client started");
        try
        {
            socket = new DatagramSocket(0);
            socket.setSoTimeout(5000);
            socket.connect(inetSocketAddress);
        } catch (SocketException e)
        {
            logMessage(e.getMessage());
            return;
        }

        final Packet packet = PacketFactory.fromBuffer(buffer, len);
        if (packet == null)
        {
            logMessage("invalid packet");
            send(PacketFactory.createErrorPacket(ErrorCode.ILLEGAL_TFTP_OPERATION));
            return;
        }
        switch (packet.getOpCode())
        {

            case RRQ:
                handleReadRequest((RequestPacket) packet);
                break;
            case WRQ:
                handleWriteRequest((RequestPacket) packet);
                break;

            default:
                logMessage("illegal TFTP operation");
                send(PacketFactory.createErrorPacket(ErrorCode.ILLEGAL_TFTP_OPERATION));
                break;
        }
        socket.close();
    }


    private void handleReadRequest(RequestPacket receivedPacket)
    {

        logMessage("reading " + outPath + receivedPacket.getFileName());
        File file = new File(outPath + receivedPacket.getFileName());


        FileInputStream fileInputStream;
        try
        {
            fileInputStream = new FileInputStream(file);
        } catch (FileNotFoundException e)
        {
            logMessage("file not found");
            send(PacketFactory.createErrorPacket(ErrorCode.FILE_NOT_FOUND));
            return;
        }
        short blockNumber = 1;

        byte[] fileBuf;
        try
        {
            fileBuf = new byte[512];
        } catch (Exception exception)
        {
            logMessage("failed to set file buffer");
            send(PacketFactory.createErrorPacket(ErrorCode.NOT_DEFINED));
            return;
        }

        int totalBytes = 0;
        if (file.length() > 0)
        {
            while (totalBytes < file.length())
            {
                // In case we want to disconnect the client
//                if (!active) {
//                    send(PacketFactory.createErrorPacket(ErrorCode.NOT_DEFINED));
//                    break;
//                }

                try
                {
                    fileInputStream.getChannel().position(totalBytes);
                    totalBytes += fileInputStream.read(fileBuf, 0, 512);
                } catch (IOException e)
                {
                    logMessage("reading failed, " + e.getMessage());
                    send(PacketFactory.createErrorPacket(ErrorCode.ACCESS_VIOLATION));
                    return;
                }
                Packet packet = PacketFactory.createDataPacket(blockNumber, fileBuf, (short) (totalBytes - ((blockNumber - 1) * 512)));
                if (packet == null)
                {
                    logMessage("failed to create data packet");
                    send(PacketFactory.createErrorPacket(ErrorCode.NOT_DEFINED));
                    break;
                }
                if (!send(packet))
                {
                    send(PacketFactory.createErrorPacket(ErrorCode.NOT_DEFINED));
                    break;
                }
                ++blockNumber;
            }
        } else
        {
            Packet packet = PacketFactory.createDataPacket(blockNumber, null, (short) 0);
            if (packet == null)
            {
                logMessage("failed to create data packet");
                send(PacketFactory.createErrorPacket(ErrorCode.NOT_DEFINED));
            }
        }

        try
        {
            fileInputStream.close();


        } catch (IOException e)
        {
            logMessage("failed to close input file");
            send(PacketFactory.createErrorPacket(ErrorCode.ACCESS_VIOLATION));
        }
        logMessage("reading finished");
    }

    private void handleWriteRequest(RequestPacket receivedPacket)
    {
        logMessage("writing " + receivedPacket.getFileName());
        File file = new File(inPath + receivedPacket.getFileName());
        if (file.exists())
        {
            logMessage("file already exists");
            send(PacketFactory.createErrorPacket(ErrorCode.FILE_ALREADY_EXISTS));
            return;
        }
        FileOutputStream fileOutputStream;
        try
        {
            fileOutputStream = new FileOutputStream(file);
        } catch (FileNotFoundException e)
        {
            logMessage("file not found");
            send(PacketFactory.createErrorPacket(ErrorCode.NOT_DEFINED));
            return;
        }
        short blockNumber = 0;
        if (!send(PacketFactory.createAcknowledgePacket(blockNumber)))
        {
            return;
        }


        int totalBytes = 0;
        int counter = 0;
        while (counter < 5)
        {
            Packet in = receive(5);
            if (in == null)
            {
                logMessage("failed to receive/create a packet");
                break;
            }
            if (in.getOpCode().equals(OpCode.ERROR))
            {
                logMessage("error message received");
                break;
            }
            if (!in.getOpCode().equals(OpCode.DATA))
            {
                logMessage("error message received");
                ++counter;
                continue;
            }
            counter = 0;

            try
            {
                fileOutputStream.getChannel().position(totalBytes);
                fileOutputStream.write(((DataPacket) in).getData());
            } catch (IOException e)
            {
                logMessage("writing failed, " + e.getMessage());
                send(PacketFactory.createErrorPacket(ErrorCode.DISK_FULL_OR_ALLOCATION_EXCEEDED));
                break;
            }
            // logMessage("got block" + blockNumber + ", " + ((DataPacket) in).getData().length);
            totalBytes += ((DataPacket) in).getData().length;
            if (!send(PacketFactory.createAcknowledgePacket(++blockNumber)))
            {
                break;
            }
            if (((DataPacket) in).getData().length != 512)
            {
                break;
            }
        }
        try
        {
            fileOutputStream.close();
        } catch (IOException e)
        {
            logMessage(e.getMessage());
            send(PacketFactory.createErrorPacket(ErrorCode.ACCESS_VIOLATION));
        }
        logMessage("writing finished");
    }


    // IO Operations
    // --------------------------
    private Packet receive(int retry)
    {
        DatagramPacket dataPacket;
        try
        {
            dataPacket = new DatagramPacket(buffer, buffer.length);
            socket.receive(dataPacket);
        } catch (IOException e)
        {
            logMessage(e.getMessage());
            if (retry <= 0)
            {
                return null;
            }
            return receive(--retry);
        }
        return PacketFactory.fromBuffer(buffer, dataPacket.getLength());
    }

    private boolean send(Packet packet)
    {
        if (packet == null)
        {
            logMessage("failed to create sending packet");
            return false;
        }
        return send(packet, 5);
    }

    private boolean send(Packet packet, int attempts)
    {
        try
        {
            socket.send(new DatagramPacket(packet.getBuffer(), packet.getBuffer().length));
        } catch (IOException e)
        {
            logMessage("failed to send packet, opcode " + OpCode.toString(packet.getOpCode()));
            if (attempts <= 0)
            {
                return false;
            }
            return send(packet, --attempts);
        }

        if (packet.getOpCode().equals(OpCode.DATA))
        {
            ByteBuffer wrap = ByteBuffer.wrap(packet.getBuffer(), 2, 2);
            short blockNumber = wrap.getShort();
            Packet recPacket = receive(0);
            // Check if error packet received
            if (packet instanceof ErrorPacket)
            {
                return false;
            }
            // Check for received packet
            // retransmit if invalid packet received
            if ((!(recPacket instanceof AcknowledgePacket)) || (((AcknowledgePacket) recPacket).getBlockNumber() != blockNumber))
            {
                logMessage("failed to receive ack packet, attempts " + attempts + ", blockNumber " + blockNumber);
                if (attempts <= 0)
                {
                    return false;
                }
                return send(packet, --attempts);
            }
        }
        return true;
    }


}
